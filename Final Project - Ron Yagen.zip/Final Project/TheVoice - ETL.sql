--Create TheVoice_Mrr

Use master
Go

Create Database TheVoice_Mrr
Go

Use TheVoice_Mrr
Go

CREATE TABLE [dbo].[mrr_countries](
	[COUNTRY_CODE] [nvarchar](100) Primary Key NOT NULL,
	[DESC] [nvarchar](100) NULL,
	[REGION] [nvarchar](100) NULL,
	[AREA] [nvarchar](100) NULL,
	[insert_date] [datetime] NULL,
	[update_date] [datetime] NULL
)
Go

CREATE TABLE [dbo].[mrr_customer](
	[customer_id] [int] Primary Key NOT NULL,
	[CUST_NUMBER] [nvarchar](20) NOT NULL,
	[cust_name] [nvarchar](100) NULL,
	[address] [nvarchar](100) NULL,
	[insert_date] [datetime] NULL,
	[update_date] [datetime] NULL
)
Go

CREATE TABLE [dbo].[mrr_customer_lines](
	[PHONE_NO] [nvarchar](20) Primary Key NOT NULL,
	[createdate] [datetime] NOT NULL,
	[enddate] [datetime] NULL,
	[status] [nvarchar](4) NULL,
	[TYPE] [nvarchar](10) NULL,
	[DESC] [nvarchar](100) NULL,
	[insert_date] [datetime] NULL,
	[update_date] [datetime] NULL,
	[discountpct] [int] NULL,
	[numberoffreeminutes] [int] NULL
)
Go

CREATE TABLE [dbo].[mrr_Package_Catalog](
	[PACKAGE_NUM] [int] Primary Key NOT NULL,
	[createdate] [datetime] NULL,
	[enddate] [datetime] NULL,
	[status] [nvarchar](4) NULL,
	[pack_type] [nvarchar](10) NULL,
	[pack_desc] [nvarchar](100) NULL,
	[insert_date] [datetime] NULL,
	[update_date] [datetime] NULL
)
Go

CREATE TABLE [dbo].[mrr_USAGE_MAIN](
	[CALL_NO] [int] Primary Key NOT NULL,
	[ANSWER_TIME] [datetime] NOT NULL,
	[SEIZED_TIME] [datetime] NOT NULL,
	[DISCONNECT_TIME] [datetime] NOT NULL,
	[CALL_DATETIME] [datetime] NULL,
	[CALLING_NO] [nvarchar](18) NULL,
	[CALLED_NO] [nvarchar](18) NULL,
	[DES_NO] [nvarchar](25) NULL,
	[DURATION] [int] NULL,
	[CUST_ID] [int] NULL,
	[CALL_TYPE] [nvarchar](20) NULL,
	[PROD_TYPE] [nvarchar](20) NULL,
	[RATED_AMNT] [int] NULL,
	[RATED_CURR_CODE] [nvarchar](10) NULL,
	[CELL] [int] NULL,
	[CELL_ORIGIN] [int] NULL,
	[HIGH_LOW_RATE] [int] NULL,
	[insert_DATE] [datetime] NULL,
	[update_date] [datetime] NULL
)
Go

CREATE TABLE [dbo].[mrr_XXCOUNTRYPRE](
	[COUNTRY_CODE] [nvarchar](100) Primary Key NOT NULL,
	[COUNTRY_PRE] [nvarchar](3) NOT NULL
)
Go

CREATE TABLE [dbo].[mrr_OPFILEOPP](
	[OPCCC] [nvarchar](10) NOT NULL,
	[OPDDD] [nvarchar](100) NOT NULL,
	[prepre] [nvarchar](3) NOT NULL
)
Go

CREATE TABLE [dbo].[mrr_call_type](
	[call_type_code] [nvarchar](10) NOT NULL,
	[call_type_desc] [nvarchar](100) NOT NULL,
	[priceperminuter] [decimal](2, 2) NOT NULL,
	[call_type] [nvarchar](100) NOT NULL
)
Go

--Create TheVoice_stg
Use master
go

create Database TheVoice_stg
Go

Use TheVoice_stg
Go

CREATE TABLE [dbo].[stg_countries](
	[COUNTRY_CODE] [nvarchar](100) Primary Key NOT NULL,
	[REGION] [nvarchar](100) NULL,
	[AREA] [nvarchar](100) NULL,
)
Go

CREATE TABLE [dbo].[stg_customer](
	[customer_id] [int] Primary Key NOT NULL,
	[CUST_NUMBER] [nvarchar](20) NOT NULL,
	[cust_name] [nvarchar](100) NULL,
	[address] [nvarchar](100) NULL,
)
Go

CREATE TABLE [dbo].[stg_customer_lines](
	[PHONE_NO] [nvarchar](20) Primary Key NOT NULL,
	[PackageType] [nvarchar](100) NULL,
	[DESC] [nvarchar](100) NULL,
	[DescCustomerLineOperator] [nvarchar](50) NULL,
	[DescCustomerLineCountry] [nvarchar](100) NULL,
	[discountpct] [int] NULL,
	[numberoffreeminutes] [int] NULL
)
Go

CREATE TABLE [dbo].[stg_Package_Catalog](
	[PACKAGE_NUM] [int] Primary Key NOT NULL,
	[PackageType] [nvarchar](100) NULL,
	[createdate] [date] NULL,
	[enddate] [date] NULL,
	[status] [nvarchar](100) NULL,
	[ActiveDays] [int] NULL,
	[pack_desc] [nvarchar](120) NULL
)
Go

CREATE TABLE [dbo].[stg_USAGE_MAIN](
	[CALL_NO] [int] Primary Key NOT NULL,
	[DATE] [date] NULL,
	[TIME] [time] NULL,
	[CALLING_NO] [nvarchar](18) NULL,
	[OriginCountry] int NULL,
	[OriginOperator] int NULL,
	[DestinationCountry] int NULL,
	[DestinationOperator] int NULL,
	[DURATION] [int] NULL,
	[CUST_ID] [int] NULL,
	[CALL_TYPE] [nvarchar](20) NULL,
	[RATED_AMNT] [int] NULL,
	[CELL_ORIGIN] [int] NULL,
)
Go

CREATE TABLE [dbo].[stg_XXCOUNTRYPRE](
	[COUNTRY_CODE] [nvarchar](100) Primary Key NOT NULL,
	[COUNTRY_PRE] [nvarchar](3) NOT NULL
)
Go

CREATE TABLE [dbo].[stg_OPFILEOPP](
	[OPCCC] [nvarchar](10) Primary Key NOT NULL,
	[OPDDD] [nvarchar](50) NOT NULL,
	[DescOperator] [nvarchar](50) NOT NULL,
	[prepre] [nvarchar](3) NOT NULL
)
Go

CREATE TABLE [dbo].[stg_call_type](
	[call_type_code] [nvarchar](10) Primary Key NOT NULL,
	[call_type_desc] [nvarchar](100) NOT NULL,
	[priceperminuter] [decimal](2, 2) NOT NULL,
	[DescFullCallType]	[nvarchar](100) NULL,
	[DescCallTypePriceCategory]	[nvarchar](100) NULL,
	[call_type] [nvarchar](100) NOT NULL
)
Go

CREATE TABLE [dbo].[stg_Parameters](
	[ParameterName] [nvarchar](100) Primary Key NOT NULL,
	[Desc] [nvarchar](100) NULL,
	[Table] [nvarchar](100) NULL,
	[Column] [nvarchar](100) NULL,
	[Value] [decimal](2, 2) NULL
)
Go

Insert into stg_Parameters
Values('p_discntprice', 'Determine if price is discounted or not', 'DimCallTypes','DescCallTypePriceCategory', 0.5)
Go


-- Create TheVoice_DW
Use master
go

create Database TheVoice_DW
Go

Use TheVoice_DW
Go

CREATE TABLE [dbo].[DimCallTypes](
	[KeyCallType] [INT] IDENTITY(1,1) Primary Key NOT NULL,
	[DescCallTypeCode] [nvarchar](100) NULL,
	[DescCallType] [nvarchar](100) NULL,
	[DescFullCallType] [nvarchar](100) NULL,
	[DescCallTypePriceCategory] [nvarchar](100) NULL,
	[DescCallTypeCategory] [nvarchar](100) NULL
)
Go

CREATE TABLE [dbo].[DimCountries](
	[KeyCountry] [INT] Identity(1,1) Primary Key NOT NULL,
	[AreaCode] [INT] NOT NULL,
	[DescCountry] [nvarchar](100) NULL,
	[DescRegion] [nvarchar](100) NULL,
	[DescArea] [nvarchar](100) NULL
)
Go

CREATE TABLE [dbo].[DimPackageCatalog](
	[KeyPackage] [INT] Primary Key NOT NULL,
	[DescPackage] [nvarchar](100) NULL,
	[DatePackageCreation] [DATE] NULL,
	[DatePackageEnd] [DATE] NULL,
	[DescPackageStatus] [nvarchar](100) NULL,
	[DescPackageActivitiesDays] [nvarchar](100) NULL,
)
Go

CREATE TABLE [dbo].[DimOperators](
	[KeyOperator] [INT] Primary Key NOT NULL,
	[DescOperator] [nvarchar](50) NULL,
	[DescKeyPrefix] [nvarchar](3) NULL
)
Go

CREATE TABLE [dbo].[DimCustomers](
	[KeyCustomer] [INT] Primary Key NOT NULL,
	[DescCustomerLineOperator] [nvarchar](50) NULL,
	[DescCustomerLineCountry] [nvarchar](100) NULL,
	[DescCustomerName] [nvarchar](100) NULL,
	[DescCustomerAddress] [nvarchar](100) NULL,
	[DescCustomerPackage] [nvarchar](100) NULL
)
Go

CREATE TABLE [dbo].[FactUsage](
	[CallId] [INT] Primary Key NOT NULL,
	[KeyCustomer] [INT] NULL,
	[KeyCallType] [INT] NULL,
	[KeyOriginCountry] [INT] NULL,
	[KeyDestinationCountry] [INT] NULL,
	[KeyOriginOperator] [INT] NULL,
	[KeyDestinationOperator] [INT] NULL,
	[KeyPackage] [INT] NULL,
	[KeyCallOriginType] [INT] NULL,
	[KeyCallDate] [INT] NULL,
	[KeycallTime] [INT] NULL,
	[Duration] [INT] NULL,
	[BillableDuration] [INT] NULL,
	[Amount] [FLOAT] NULL,
	[BillableAmount] [FLOAT] NULL,
)
Go

CREATE TABLE [dbo].[DimCallOriginType](
	[KeyCallOriginType] [INT] Primary Key NOT NULL,
	[DescCallOriginType] [nvarchar](100) NULL
)
Go

Insert into DimCallOriginType
Values
(0, 'Line Call'),
(1, 'Cellular Call'),
(-1, 'Unknown')


--Create DimDate Table
CREATE TABLE	[dbo].[DimDate]
	(	[KeyDate] INT primary key, 
		[FullDate] DATE,
		[KeyYear] INT,
		[CodeYear] INT,
		[DescYear] NVARCHAR(50),
		[KeyMonth] INT,
		[CodeMonth] INT,
		[DescMonth] NVARCHAR(50),
		[CodeDayInWeek] INT,
		[DescDayInWeek] NVARCHAR(50)
	)
GO

--Populating DimDate Table
Declare @startdate DATE = '2013-01-01', @enddate DATE = '2021-12-31'

Declare @currentdate DATE = @startdate

While DATEDIFF(dd,@currentdate,@enddate)>=0
Begin
declare 
@key int = convert(int,convert(nvarchar(20), @currentdate, 112)),
@year int = year(@currentdate),
@month int = month(@currentdate),
@dayoftheweek nvarchar(20) = FORMAT(@currentdate,'dddd')

Declare @dayoftheweekcode int = 
case @dayoftheweek
When 'Sunday' Then 7
When 'Monday' Then 1
When 'Tuesday' Then 2
When 'Wednesday' Then 3
When 'Thursday' Then 4
When 'Friday' Then 5
When 'Saturday' Then 6
end

Insert into DimDate
Values(@key, @currentdate, @year, @year, convert(nvarchar(20),@year),LEFT(@key,6), @month, FORMAT(@currentdate,'MMMM'),@dayoftheweekcode, @dayoftheweek)

set @currentdate = DATEADD(dd,1,@currentdate)
End

Go

--Create DimTime Table

CREATE TABLE	[dbo].[DimTime]
	(	[KeyTime] INT primary key, 
		[FullTime] Time(0),
		[CodeHour] INT,
		[DescHour] NVARCHAR(50),
		[KeyMinute] INT,
		[CodeMinute] INT,
		[DescMinute] NVARCHAR(50)
	)
GO

--Populating DimTime Table

Declare @starttime time = '00:00:00'
declare @currenttime time = @starttime
declare @key int =  Convert(int,Replace(Left(Convert(nvarchar(8), @currenttime),5), ':', ''))
while @key<2359
begin
declare @codehour int = DATEPART(hh,@currenttime),
@hour nvarchar(50) = 
Case Len(DATENAME(hour, @currenttime))
when 1 then '0' + DATENAME(hour, @currenttime)
When 2 then DATENAME(hour, @currenttime)
end

Declare @keyminute int = @key,
@codeminute int = DATEPART(minute,@currenttime),
@minute nvarchar(50) = 
CASE LEN(DATENAME(minute, @currenttime))
WHEN 1 THEN '0' + DATENAME(minute, @currenttime)
WHEN 2 THEN DATENAME(minute, @currenttime)
END

Insert into DimTime
Values(@key,@currenttime,@codehour,@hour,@keyminute,@codeminute,@minute)

set @currenttime = DATEADD(MINUTE,1,@currenttime)
set @key =  Convert(int,Replace(Left(Convert(nvarchar(8), @currenttime),5), ':', ''))
end

set @codehour = DATEPART(hh,@currenttime)
set @hour = 
Case Len(DATENAME(hour, @currenttime))
when 1 then '0' + DATENAME(hour, @currenttime)
When 2 then DATENAME(hour, @currenttime)
end

set @keyminute  = @key
set @codeminute  = DATEPART(minute,@currenttime)
set @minute  = 
CASE LEN(DATENAME(minute, @currenttime))
WHEN 1 THEN '0' + DATENAME(minute, @currenttime)
WHEN 2 THEN DATENAME(minute, @currenttime)
END

Insert into DimTime
Values(@key,@currenttime,@codehour,@hour,@keyminute,@codeminute,@minute)
Go



