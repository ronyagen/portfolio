--Select

use TheVoice_Mrr
go

select * from mrr_countries
Select * from mrr_customer
Select * from mrr_customer_lines
Select * from mrr_OPFILEOPP
Select * from mrr_Package_Catalog
Select * from mrr_usage_main
Select * from mrr_XXCOUNTRYPRE
Select * from mrr_call_type

use TheVoice_stg
go

select * from stg_countries
Select * from stg_customer
Select * from stg_customer_lines
Select * from stg_OPFILEOPP
Select * from stg_Package_Catalog
Select * from stg_usage_main
Select * from stg_XXCOUNTRYPRE
Select * from stg_call_type
Select * from stg_Parameters

use TheVoice_DW
Go

Select * from DimDate
Select * from DimTime
Select * From DimCallOriginType
Select * From DimCallTypes
Select * From DimOperators
Select * From DimCustomers
Select * From DimPackageCatalog
Select * From DimCountries
Select * From FactUsage

--Truncate

use TheVoice_Mrr
go

Truncate Table mrr_countries
Truncate Table mrr_customer
Truncate Table mrr_customer_lines
Truncate Table mrr_OPFILEOPP
Truncate Table mrr_Package_Catalog
Truncate Table mrr_usage_main
Truncate Table mrr_XXCOUNTRYPRE
Truncate Table mrr_call_type

use TheVoice_stg
go

Truncate Table stg_countries
Truncate Table stg_customer
Truncate Table stg_customer_lines
Truncate Table stg_OPFILEOPP
Truncate Table stg_Package_Catalog
Truncate Table stg_usage_main
Truncate Table stg_XXCOUNTRYPRE
Truncate Table stg_call_type
Truncate Table stg_Parameters

use TheVoice_DW
Go

Truncate Table DimDate
Truncate Table DimTime
Truncate Table DimCallOriginType
Truncate Table DimCallTypes
Truncate Table DimOperators
Truncate Table DimCustomers
Truncate Table DimPackageCatalog
Truncate Table DimCountries
Truncate Table FactUsage