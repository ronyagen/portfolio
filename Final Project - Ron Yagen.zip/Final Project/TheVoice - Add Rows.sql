use TheVoice
go

--In order to run this query there must be data in stg_call_type table!!

-- Enter Start date, End Date and numbers of rows to add
Declare @startdate datetime = '2020-01-01',
@enddate datetime = '2020-12-31',
@rows int =100

set ANSI_WARNINGS  OFF

Declare @call_types table(call_type nvarchar(10), PROD_TYPE nvarchar(20), PricePerMinute float)
Insert into @call_types
Select call_type_code, call_type_desc, priceperminuter  from thevoice_stg.dbo.stg_call_type CT

Declare 
@secdiff int,
@seizedtime datetime,
@curr nvarchar(20),
@custid int,
@desno nvarchar(30),
@calltype nvarchar(10),
@answertime datetime,
@prodtype nvarchar(20),
@callingno nvarchar(30),
@calldate date,
@discontime datetime,
@duration int,
@priceperminute float,
@rated_amnt int,
@cell int = 0, 
@cellorigin int = 0

While @rows > 0
Begin

set @secdiff = Datediff(Second, @startdate,@enddate)*Rand() + 1
set @seizedtime = Dateadd(second, @secdiff, @startdate)
set @curr = 'SHEKEL'
set @custid = (Select Top 1 customer_id from customer Order By NEWID())
set @desno = (Select Top 1 CUST_NUMBER from customer Order By NEWID())
set @calltype = (Select Top 1 call_type from @call_types Order By NEWID())
set @answertime = Dateadd(second, Round(Rand()*100,0), @seizedtime)
set @prodtype = (Select prod_type from @call_types Where call_type = @calltype)
set @callingno = (Select CUST_NUMBER from customer Where customer_id = @custid)
set @calldate = Convert(date, @seizedtime)
set @discontime = Dateadd(second, Round(Rand()*1000,0), @answertime)
set @duration = Datediff(MINUTE,@answertime, @discontime)
set @priceperminute = (Select PricePerMinute from @call_types Where call_type = @calltype)
set @rated_amnt = @duration*@priceperminute
set @cell = 0
set @cellorigin = 0

if @callingno like '+972%'
set @cellorigin = 1

if @desno like '+972%'
set @cell = 1


Insert into usage_main
Values(@answertime,@seizedtime,@discontime, @calldate,@callingno,@desno,@desno,@duration,@custid,@calltype,@prodtype, @rated_amnt,@curr, @cell, @cellorigin, 1, getdate(), null)

set @rows = @rows - 1

END

set ANSI_WARNINGS  ON


