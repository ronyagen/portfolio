Create Database CATCH_THE_FISH
Go

use CATCH_THE_FISH
go

Create Table Countries
(
	CountryCode nvarchar(2) primary key,
	CountryName nvarchar(40) not null
)

Go

Create Table Genders
(
	GenderCode char(1) Primary key,
	GenderName nvarchar(20) not null
)

Go

Create Table Players
(
	PlayerID int Primary key,
	PlayerName nvarchar(20) not null
)

Go

Create Table Users
(
	UserName nvarchar(20) Primary Key,
	Password nvarchar(20) COLLATE SQL_Latin1_General_CP1_CS_AS not null,
	FirstName nvarchar(20) not null,
	LastName nvarchar(20) not null,
	Address nvarchar(50),
	Country nvarchar(2),
	Email nvarchar(30) Unique,
	Gender char(1),
	BirthDate date,
	LoggedIn tinyint default(0),
	InvalidEntry tinyint default(0),
	Blocked tinyint default(0),
	Balance int default(1000),

	Foreign Key(Country) references Countries,
	Foreign Key(Gender) references Genders,
	Check (Balance >= 0),
	Check (Blocked In (0,1)),
	Check (InvalidEntry >= 0 AND InvalidEntry <= 3),
	Check (LoggedIn In (0,1))
)

Go

Create Table Games
(
	GameID int IDENTITY(1000,1) PRIMARY KEY,
	UserName nvarchar(20) not null,
	GuessID int,
	WinnerID int,
	result char(1),
	reward int,

	Foreign Key(UserName) references Users(UserName),
	Foreign Key(GuessID) references Players,
	Foreign Key(WinnerID) references Players,
	Check (reward In (1000,-100))
)


Go

--Views

--Get Random Number 0-1
Create View vw_getRandom
As
select rand() as Value

Go

--Get Logged In User Name
Create View vw_loggedin
As
Select UserName from Users where LoggedIn = 1

Go

-- Get Scoreboard (Should be created after fn_winprcnt is created!)
Create view vw_rnk_table
As
Select Rank() over(Order by Balance desc) Rank,
UserName, [Total Games],
Wins, 
Loses,
dbo.fn_winprcnt(wins,[Total Games]) [Win Ratio],
Balance
From
(
Select U.UserName, 
count(G.UserName) As [Total Games],
Count(Case result when 'W' then 1 end) As Wins,
Count(Case result when 'L' then 1 end) As Loses, 
Balance
From Users U
Left Join Games G
On U.UserName = G.UserName
group by U.UserName, balance
) As sb

Go

--Functions

--Check if Username exists and if it does suggest alternative
Create Function fn_NewUN (@user nvarchar(20))
Returns nvarchar(20)
AS
begin
If exists(Select * From Users Where UserName = @user)
	begin
	declare @rnd int = (Select Value From vw_getRandom)*10
	set @user = @user+convert(nvarchar(20),@rnd)
	set @user = dbo.fn_NewUN(@user)
	end
return @user
End

Go

--Check if password is "Strong"
Create Function fn_Check_PW (@pw nvarchar(20), @un nvarchar(20))
returns int
as
begin
declare @x int = 1
If @pw <> UPPER(@pw) COLLATE SQL_Latin1_General_CP1_CS_AS
	AND @pw <> Lower(@pw) COLLATE SQL_Latin1_General_CP1_CS_AS
	AND @pw Like '%[0-9]%'
	AND Len(@pw) >= 7
	AND @pw <> @un
	set @x = 0

return @x
end

Go

--Check if mail valid and unique
Create Function fn_check_mail(@mail nvarchar(30))
returns int
AS
begin
	declare @x int=0

	If @mail Like '%@%'
		begin
		If exists (Select * from Users where email = @mail)
			set @x = 1
		End
	Else
		set @x = 2

	return @x
end

Go

--Check if age over 13
Create Function fn_check_age (@bdate date)
returns int
AS
begin

declare @age int, @ret int = 0

set @age = DATEDIFF(DD, @bdate, GetDate())/365.25

if @age < 13
	set @ret = 1

return @ret

end

Go

--Get balance for user
Create Function fn_getBalance (@user nvarchar(20))
returns int
as
begin
declare @bal int
set @bal =  (Select balance from users where username = @user)
return @bal
end

go

--Get float result for dividing two integers (win ratio)
Create function fn_winprcnt (@win int, @total int)
returns float
as
begin
declare @w float = @win*1.0, @t float = @total, @res float 
If @total =0
	set @res = 0
Else
	Begin
	set @res= @w/@t
	End
return @res
end

Go

--Generate new random password
Create Function fn_generatepw()
returns nvarchar(20)
as
begin
Declare @chars nvarchar(80)='0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz' 
COLLATE SQL_Latin1_General_CP1_CS_AS
declare @n int= (select value from vw_getRandom)*61+1, @newpass nvarchar(20), @count int = 7
set @newpass = SUBSTRING(@chars,@n,1)
while @count > 1
	begin
	set @n= (select value from vw_getRandom)*61+1
	set @newpass = @newpass+ SUBSTRING(@chars,@n,1)
	set @count = @count -1
	end

return @newpass
end

Go

--Check if new password is strong and if not generates new password
Create Function fn_gen_strongpw(@user nvarchar(20))
returns nvarchar(20)
AS
begin
declare @newpw nvarchar(20) = dbo.fn_generatepw()
while dbo.fn_Check_PW(@newpw,@user) = 1
	set @newpw = dbo.fn_generatepw()
return @newpw
end

Go

--Stored Procedures
-- Registration Procedure
Create Procedure sp_registration 
(
@user nvarchar(20),
@pw nvarchar(20),
@fn nvarchar(20),
@ln nvarchar(20),
@address nvarchar(50),
@Country nvarchar(40),
@Email nvarchar(30),
@gender nvarchar(20),
@bdatetxt nvarchar(10)
)
As

Declare 
@var_user int = 0,
@var_pw int = 0,
@var_Country int = 0,
@var_Email int = 0,
@bdate date = convert(date,@bdatetxt),
@var_bdate int = 0


If @user <> dbo.fn_newUN(@user)
	set @var_user = 1

set @var_pw = dbo.fn_check_PW(@pw,@user)

set @var_email = dbo.fn_check_mail(@Email)

set @var_bdate = dbo.fn_check_age(@bdate)

set @Country = (Select CountryCode from Countries where CountryName = @Country)

set @gender = (select GenderCode from Genders where GenderName = @gender)

If @var_user + @var_pw + @var_Email + @var_bdate > 0
begin
	print 'Your registration form had the following errors:'
	If @var_user = 1  print '- The User Name you entered already exists. The following User Name is available: ' + dbo.fn_newUN(@user)
	If @var_pw = 1  print '- The password you selected is weak. Note that the password must be different than the User Name selected and contain at least 1 uppercase letter, 1 lowercase letter and 1 digit.'

	declare @mailprint nvarchar(80)
	set @mailprint = 
	Case @var_email when 1 then '- The mail address selected is already used. Please select a new mail address.'
	when 2 then '- The mail address selected is invalid. Mail address must contain @.'
	end
	print @mailprint

	If @var_bdate = 1  print '-  Unfortunately, Players below the age of 13 can''t register.'

	print ''
	print 'Please fix the details above and try to register again.'

end
Else
begin

	Insert into Users(UserName, Password, FirstName, LastName, Address, Country, Email, Gender, BirthDate)
	Values(@user,@pw,@fn,@ln,@address,@Country,@Email,@gender,@bdate)

	print 'Registration Completed Successfuly. 1000 points were added to your balance as a welcome gift.'
	print 'Please Log In with your User Name and Password to start playing.'
end

Go
--Procedure that plays the game and returns the winner ID
Create Procedure sp_game
(@winner int output)
As

declare @avi int = 0, 
@moshe int = 0, 
@shir int = 0, 
@count int = 10, 
@steps int = 100, 
@turn int = 10

While @count > 0
begin
print Replicate('~',@steps)
print ' '
print Replicate(' ',@avi)+'><(((o>'
print ' '
print Replicate(' ',@moshe)+'><(((o>'
print ' '
print Replicate(' ',@shir)+'><(((o>'
print ' '
print Replicate('~',@steps)

Set @avi = @avi + Rand()*@turn + 1
Set @moshe = @moshe + Rand()*@turn + 1
Set @shir = @shir + Rand()*@turn + 1

set @count = @count -1

end

set @winner = Rand()*3+1

print Replicate('~',@steps)
print ' '
If @winner = 1
	print Replicate(' ',@avi)+'-------'
print Replicate(' ',@avi)+'><(((o>'
If @winner = 1
	print Replicate(' ',@avi)+'-------'
print ' '
If @winner = 2
	print Replicate(' ',@moshe)+'-------'
print Replicate(' ',@moshe)+'><(((o>'
If @winner = 2
	print Replicate(' ',@moshe)+'-------'
print ' '
If @winner = 3
	print Replicate(' ',@shir)+'-------'
print Replicate(' ',@shir)+'><(((o>'
If @winner = 3
	print Replicate(' ',@shir)+'-------'
print ' '
print Replicate('~',@steps)

Declare @wname nvarchar(20)

set @wname = (Select PlayerName From Players where PlayerID = @winner)

Print @wname + ' is the winner!!'

Go

--Procedure to play the game and record it
Create Procedure sp_PlayGame (@player nvarchar(20))
As

If not exists (select * from dbo.vw_LoggedIn)
	print 'No user is logged in.'
Else if (select dbo.fn_getBalance((select * from dbo.vw_LoggedIn))) < 100
	print 'You don''t have sufficient points. In order to play you required to have 100 points in your balance.'
Else
	Begin
	declare @winid int, @guessid int, @reward int, @score char(1)
	exec dbo.sp_game @winner = @winid output

	set @guessid = (select PlayerID from Players where PlayerName = @player)

	If @guessid = @winid
		begin
			set @score = 'W'
			set @reward = 1000
			print 'Congratulations! You won! 1000 points were added to your balance.'
		end
	Else
		begin
			set @score = 'L'
			set @reward = -100
			print 'Sorry, you Lost. 100 points were deducted from your balance.'
		end
	Insert into Games
	Values((select * from dbo.vw_LoggedIn),@guessid,@winid,@score,@reward)
	End

go

--Procedure to log out current user
Create Procedure sp_LogOut
As
if not exists (select * from vw_loggedin)
	Print 'Can''t log out - No user is logged in.'
Else
	begin
	declare @cur_user nvarchar(20) = (select * from vw_loggedin) 
	update Users
	set LoggedIn = 0
	where UserName = @cur_user

	print 'User ' + @cur_user + ' logged out successfully.'
	end

Go

--Procedure to get current user scoreboard
Create Procedure sp_showrank
As
if not exists (select * from vw_loggedin)
	Print 'Please log in to see your rank.'
Else
	begin
	Select *
	From vw_rnk_table
	where UserName = (select * from vw_loggedin)
	end

Go

--Unblock user and generate new password
Create Procedure sp_unblock (@user nvarchar(20))
As
If (Select Blocked from Users where UserName = @user) = 0
	print 'User is already unblocked.'
Else
	begin
	declare @newpw nvarchar(20) = dbo.fn_gen_strongpw(@user)
	print 'User ' + @user + ' is now unblocked and new password was generated. New password is:' + @newpw
	update Users
	set Blocked = 0,
		Password = @newpw,
		InvalidEntry = 0
	where UserName = @user
	end

Go

--Log in procedure
Create Procedure sp_login (@user nvarchar(20), @pw nvarchar(20))
As
If exists (select * from vw_loggedin)
	print 'Can''t log in since another user is logged in.'
Else If not exists (select UserName from Users where UserName = @user)
	print 'User Name does not exist. Please try again.'
Else if (select blocked from users where username = @user) = 1
	print 'User '+ @user + ' is blocked. Please contact support.'
Else if @pw <> (select Password from Users where UserName =@user) COLLATE SQL_Latin1_General_CP1_CS_AS
	begin
	update Users
	set InvalidEntry = InvalidEntry+1
	where UserName = @user
	declare @try int = 3 - (Select InvalidEntry from users where UserName = @user)
	print 'Password is incorrect. Please try again. Remaining tries: ' + convert(nvarchar(20),@try)
	end
Else
	begin
	update Users
	set LoggedIn = 1
	where UserName = @user
	print 'User '+ @user + ' logged in successfully.'
	end

Go

--Triggers
--Update balance after user played a game
Create Trigger update_balance
on Games
for insert
as
begin
declare @uname nvarchar(20),@reward int

select @uname = UserName, @reward = reward from inserted

Update Users
set balance = balance + @reward
where UserName = @uname
end
go

--Trigger to block user when he reaches 3 failed attempts
Create Trigger block_user
on Users
for update
as
begin
if update(InvalidEntry)
	begin
	declare @user nvarchar(20) = (Select UserName from inserted)
	If (select InvalidEntry from Users where UserName = @user) = 3
		begin
		update Users
		set Blocked =1
		where UserName = @user

		print 'You reached the maximum amount of log in attempts. User ' + @user + ' is now blocked. Please contact support.'
		end
	end
end

Go

--Tables population

Insert into Players
Values(1, 'Avi'), (2, 'Moshe'), (3, 'Shir')

Go

Insert Into Genders
Values('F', 'Female'),('M','Male')

Go

Insert into Countries
Values
('AF', 'Afghanistan'),
('AL', 'Albania'),
('DZ', 'Algeria'),
('DS', 'American Samoa'),
('AD', 'Andorra'),
('AO', 'Angola'),
('AI', 'Anguilla'),
('AQ', 'Antarctica'),
('AG', 'Antigua and Barbuda'),
('AR', 'Argentina'),
('AM', 'Armenia'),
('AW', 'Aruba'),
('AU', 'Australia'),
('AT', 'Austria'),
('AZ', 'Azerbaijan'),
('BS', 'Bahamas'),
('BH', 'Bahrain'),
('BD', 'Bangladesh'),
('BB', 'Barbados'),
('BY', 'Belarus'),
('BE', 'Belgium'),
('BZ', 'Belize'),
('BJ', 'Benin'),
('BM', 'Bermuda'),
('BT', 'Bhutan'),
('BO', 'Bolivia'),
('BA', 'Bosnia and Herzegovina'),
('BW', 'Botswana'),
('BV', 'Bouvet Island'),
('BR', 'Brazil'),
('IO', 'British Indian Ocean Territory'),
('BN', 'Brunei Darussalam'),
('BG', 'Bulgaria'),
('BF', 'Burkina Faso'),
('BI', 'Burundi'),
('KH', 'Cambodia'),
('CM', 'Cameroon'),
('CA', 'Canada'),
('CV', 'Cape Verde'),
('KY', 'Cayman Islands'),
('CF', 'Central African Republic'),
('TD', 'Chad'),
('CL', 'Chile'),
('CN', 'China'),
('CX', 'Christmas Island'),
('CC', 'Cocos (Keeling) Islands'),
('CO', 'Colombia'),
('KM', 'Comoros'),
('CD', 'Democratic Republic of the Congo'),
('CG', 'Republic of Congo'),
('CK', 'Cook Islands'),
('CR', 'Costa Rica'),
('HR', 'Croatia (Hrvatska)'),
('CU', 'Cuba'),
('CY', 'Cyprus'),
('CZ', 'Czech Republic'),
('DK', 'Denmark'),
('DJ', 'Djibouti'),
('DM', 'Dominica'),
('DO', 'Dominican Republic'),
('TP', 'East Timor'),
('EC', 'Ecuador'),
('EG', 'Egypt'),
('SV', 'El Salvador'),
('GQ', 'Equatorial Guinea'),
('ER', 'Eritrea'),
('EE', 'Estonia'),
('ET', 'Ethiopia'),
('FK', 'Falkland Islands (Malvinas)'),
('FO', 'Faroe Islands'),
('FJ', 'Fiji'),
('FI', 'Finland'),
('FR', 'France'),
('FX', 'France, Metropolitan'),
('GF', 'French Guiana'),
('PF', 'French Polynesia'),
('TF', 'French Southern Territories'),
('GA', 'Gabon'),
('GM', 'Gambia'),
('GE', 'Georgia'),
('DE', 'Germany'),
('GH', 'Ghana'),
('GI', 'Gibraltar'),
('GK', 'Guernsey'),
('GR', 'Greece'),
('GL', 'Greenland'),
('GD', 'Grenada'),
('GP', 'Guadeloupe'),
('GU', 'Guam'),
('GT', 'Guatemala'),
('GN', 'Guinea'),
('GW', 'Guinea-Bissau'),
('GY', 'Guyana'),
('HT', 'Haiti'),
('HM', 'Heard and Mc Donald Islands'),
('HN', 'Honduras'),
('HK', 'Hong Kong'),
('HU', 'Hungary'),
('IS', 'Iceland'),
('IN', 'India'),
('IM', 'Isle of Man'),
('ID', 'Indonesia'),
('IR', 'Iran (Islamic Republic of)'),
('IQ', 'Iraq'),
('IE', 'Ireland'),
('IL', 'Israel'),
('IT', 'Italy'),
('CI', 'Ivory Coast'),
('JE', 'Jersey'),
('JM', 'Jamaica'),
('JP', 'Japan'),
('JO', 'Jordan'),
('KZ', 'Kazakhstan'),
('KE', 'Kenya'),
('KI', 'Kiribati'),
('KP', 'Korea, Democratic People''s Republic of'),
('KR', 'Korea, Republic of'),
('XK', 'Kosovo'),
('KW', 'Kuwait'),
('KG', 'Kyrgyzstan'),
('LA', 'Lao People''s Democratic Republic'),
('LV', 'Latvia'),
('LB', 'Lebanon'),
('LS', 'Lesotho'),
('LR', 'Liberia'),
('LY', 'Libyan Arab Jamahiriya'),
('LI', 'Liechtenstein'),
('LT', 'Lithuania'),
('LU', 'Luxembourg'),
('MO', 'Macau'),
('MK', 'North Macedonia'),
('MG', 'Madagascar'),
('MW', 'Malawi'),
('MY', 'Malaysia'),
('MV', 'Maldives'),
('ML', 'Mali'),
('MT', 'Malta'),
('MH', 'Marshall Islands'),
('MQ', 'Martinique'),
('MR', 'Mauritania'),
('MU', 'Mauritius'),
('TY', 'Mayotte'),
('MX', 'Mexico'),
('FM', 'Micronesia, Federated States of'),
('MD', 'Moldova, Republic of'),
('MC', 'Monaco'),
('MN', 'Mongolia'),
('ME', 'Montenegro'),
('MS', 'Montserrat'),
('MA', 'Morocco'),
('MZ', 'Mozambique'),
('MM', 'Myanmar'),
('NA', 'Namibia'),
('NR', 'Nauru'),
('NP', 'Nepal'),
('NL', 'Netherlands'),
('AN', 'Netherlands Antilles'),
('NC', 'New Caledonia'),
('NZ', 'New Zealand'),
('NI', 'Nicaragua'),
('NE', 'Niger'),
('NG', 'Nigeria'),
('NU', 'Niue'),
('NF', 'Norfolk Island'),
('MP', 'Northern Mariana Islands'),
('NO', 'Norway'),
('OM', 'Oman'),
('PK', 'Pakistan'),
('PW', 'Palau'),
('PS', 'Palestine'),
('PA', 'Panama'),
('PG', 'Papua New Guinea'),
('PY', 'Paraguay'),
('PE', 'Peru'),
('PH', 'Philippines'),
('PN', 'Pitcairn'),
('PL', 'Poland'),
('PT', 'Portugal'),
('PR', 'Puerto Rico'),
('QA', 'Qatar'),
('RE', 'Reunion'),
('RO', 'Romania'),
('RU', 'Russian Federation'),
('RW', 'Rwanda'),
('KN', 'Saint Kitts and Nevis'),
('LC', 'Saint Lucia'),
('VC', 'Saint Vincent and the Grenadines'),
('WS', 'Samoa'),
('SM', 'San Marino'),
('ST', 'Sao Tome and Principe'),
('SA', 'Saudi Arabia'),
('SN', 'Senegal'),
('RS', 'Serbia'),
('SC', 'Seychelles'),
('SL', 'Sierra Leone'),
('SG', 'Singapore'),
('SK', 'Slovakia'),
('SI', 'Slovenia'),
('SB', 'Solomon Islands'),
('SO', 'Somalia'),
('ZA', 'South Africa'),
('GS', 'South Georgia South Sandwich Islands'),
('SS', 'South Sudan'),
('ES', 'Spain'),
('LK', 'Sri Lanka'),
('SH', 'St. Helena'),
('PM', 'St. Pierre and Miquelon'),
('SD', 'Sudan'),
('SR', 'Suriname'),
('SJ', 'Svalbard and Jan Mayen Islands'),
('SZ', 'Swaziland'),
('SE', 'Sweden'),
('CH', 'Switzerland'),
('SY', 'Syrian Arab Republic'),
('TW', 'Taiwan'),
('TJ', 'Tajikistan'),
('TZ', 'Tanzania, United Republic of'),
('TH', 'Thailand'),
('TG', 'Togo'),
('TK', 'Tokelau'),
('TO', 'Tonga'),
('TT', 'Trinidad and Tobago'),
('TN', 'Tunisia'),
('TR', 'Turkey'),
('TM', 'Turkmenistan'),
('TC', 'Turks and Caicos Islands'),
('TV', 'Tuvalu'),
('UG', 'Uganda'),
('UA', 'Ukraine'),
('AE', 'United Arab Emirates'),
('GB', 'United Kingdom'),
('US', 'United States'),
('UM', 'United States minor outlying islands'),
('UY', 'Uruguay'),
('UZ', 'Uzbekistan'),
('VU', 'Vanuatu'),
('VA', 'Vatican City State'),
('VE', 'Venezuela'),
('VN', 'Vietnam'),
('VG', 'Virgin Islands (British)'),
('VI', 'Virgin Islands (U.S.)'),
('WF', 'Wallis and Futuna Islands'),
('EH', 'Western Sahara'),
('YE', 'Yemen'),
('ZM', 'Zambia'),
('ZW', 'Zimbabwe')
