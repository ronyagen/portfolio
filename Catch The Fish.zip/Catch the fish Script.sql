use CATCH_THE_FISH
go

Create view vw_rnk_table
As
Select Rank() over(Order by Balance desc) Rank, UserName, [Total Games], Wins, Loses,dbo.fn_winprcnt(wins,[Total Games]) [Win Ratio], Balance
From
(
Select U.UserName, count(G.UserName) As [Total Games],Count(Case result when 'W' then 1 end) As Wins,Count(Case result when 'L' then 1 end) As Loses, Balance
From Users U
Left Join Games G
On U.UserName = G.UserName
group by U.UserName, balance
) As sb

Select U.UserName, G.*, Balance
From Users U
Left Join Games G
On U.UserName = G.UserName


Select *
Drop view vw_rnk_table

Select U.UserName, Case result when 'W' then 1 end, Case result when 'L' then 1 end, Balance
From Users U
Left Join Games G
On U.UserName = G.UserName

Drop procedure dbo.sp_registration
exec sp_PlayGame 'Shir'

select dbo.fn_winprcnt(2,8)
drop function dbo.fn_winprcnt


Create function fn_winprcnt (@win int, @total int)
returns float
as
begin
declare @w float = @win*1.0, @t float = @total, @res float 
set @res= @w/@t
return @res
end


print @winid

Create Procedure sp_LogOut
As
if not exists (select * from vw_loggedin)
	Print 'Can''t log out - No user is logged in.'
Else
	begin
	declare @cur_user nvarchar(20) = (select * from vw_loggedin) 
	update Users
	set LoggedIn = 0
	where UserName = @cur_user

	print 'User ' + @cur_user + ' logged out successfully.'
	end




	use CATCH_THE_FISH
go

Create Function fn_generatepw()
returns nvarchar(20)
as
begin
Declare @chars nvarchar(80)='0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz' COLLATE SQL_Latin1_General_CP1_CS_AS
declare @n int= (select value from vw_getRandom)*61+1, @newpass nvarchar(20), @count int = 7
set @newpass = SUBSTRING(@chars,@n,1)
while @count > 1
	begin
	set @n= (select value from vw_getRandom)*61+1
	set @newpass = @newpass+ SUBSTRING(@chars,@n,1)
	set @count = @count -1
	end

return @newpass
end


drop function dbo.fn_generatepw

Create Function fn_gen_strongpw(@user nvarchar(20))
returns nvarchar(20)
AS
begin
declare @newpw nvarchar(20) = dbo.fn_generatepw()
while dbo.fn_Check_PW(@newpw,@user) = 1
	set @newpw = dbo.fn_generatepw()
return @newpw
end

select dbo.fn_gen_strongpw('rony')


Create Procedure sp_unblock (@user nvarchar(20))
As
If (Select Blocked from Users where UserName = @user) = 0
	print 'User is already unblocked.'
Else
	begin
	declare @newpw nvarchar(20) = dbo.fn_gen_strongpw(@user)
	print 'User ' + @user + ' is now unblocked and new password was generated. New password is:' + @newpw
	update Users
	set Blocked = 0,
		Password = @newpw
	where UserName = @user
	end

exec sp_unblock 'rony'

select * from Users 
		


Exec sp_LogOut
drop procedure sp_LogOut

	update Users
	set InvalidEntry = 0
	where UserName = 'rony'

Create Procedure sp_showrank
As
if not exists (select * from vw_loggedin)
	Print 'Please log in to see your rank.'
Else
	begin
	Select *
	From vw_rnk_table
	where UserName = (select * from vw_loggedin)
	end

drop procedure sp_showrank
exec sp_showrank

Create Procedure sp_login (@user nvarchar(20), @pw nvarchar(20))
As
If exists (select * from vw_loggedin)
	print 'Can''t log in since another user is logged in.'
Else If not exists (select UserName from Users where UserName = @user)
	print 'User Name does not exist. Please try again.'
Else if (select blocked from users where username = @user) = 1
	print 'User '+ @user + ' is blocked. Please contact support.'
Else if @pw <> (select Password from Users where UserName =@user) COLLATE SQL_Latin1_General_CP1_CS_AS
	begin
	update Users
	set InvalidEntry = InvalidEntry+1
	where UserName = @user
	declare @try int = 3 - (Select InvalidEntry from users where UserName = @user)
	print 'Password is incorrect. Please try again. Remaining tries: ' + convert(nvarchar(20),@try)
	end
Else
	begin
	update Users
	set LoggedIn = 1
	where UserName = @user
	print 'User '+ @user + ' logged in successfully.'
	end

drop procedure sp_login
exec sp_login 'rony','3QgPRp0'

exec sp_LogOut

drop trigger block_user
Create Trigger block_user
on Users
for update
as
begin
if update(InvalidEntry)
	begin
	declare @user nvarchar(20) = (Select UserName from inserted)
	If (select InvalidEntry from Users where UserName = @user) = 3
		begin
		update Users
		set Blocked =1
		where UserName = @user

		print 'You reached the maximum amount of log in attempts. User ' + @user + ' is now blocked. Please contact support.'
		end
	end
end
